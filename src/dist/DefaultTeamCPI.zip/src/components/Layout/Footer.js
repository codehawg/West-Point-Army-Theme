import './Footer.scss'

/**
 * This component represents the footer in the store
 */
const Footer = () => {
  return (
    <div className="footer">
    </div>
  )
}

export default Footer
